#1写个类
import time
class   Person:
    #1 属性
    def __init__(self,name,age,money): #构造对象方法
        #对象属性名字
        self.name = name #创造对象 对象设置
        self.__age = age #注入
        self.__money=money
     #  get属性  企业习惯   ----》给这个属性 增加读权限
    def  getAge(self):
        print('年龄是',self.__age)
    #  set 属性  企业习惯   ----》给这个属性 增加改权限
    # money 可改不可读
    def setMoney(self,money):
        self.__money=money



    def dai_wa(self):
        print(f'{self.__age}岁的{self.name}在带娃')
    def zuo_fa(self):
        print(f'{self.__age}岁的{self.name}在做饭')

    def __str__(self):
        return  f'对象名字:{self.name}对象年龄:{self.__age},金钱{self.__money}'
# 2实例化对象
p1=Person('小美',18,20000)   #匿名调用 了  __init__构造方法
p2=Person('小王',28,30000)
p3=Person('小白',38,10000)
p4=Person('小白',38,30000)
if __name__ == '__main__': #自测
    print(p1.name)
    #print(p1.__age,p1.__money)
    p1.getAge()#读年龄

    print(p1)
    p1.setMoney(0) #修改金钱
    print(p1)




