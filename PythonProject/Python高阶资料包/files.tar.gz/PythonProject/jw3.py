class Animal: #共性
    def __init__(self,name,age):
        self.name=name
        self.age=age
    def shout(self):
        print(f'{self.name}在大叫～')
    def eat(self):
        print(f'{self.name}在吃东西～')
    #可以被所有子类使用
    def  __str__(self):
        return   f'{self.name},{self.age}'
#   子类（父类 ）  ===》相对概念
class  Dog(Animal): #相对于 AisaDog --》Dog父类
    #color='黄色'    #类属性（对象出生之前确认属性）
                   #对象属性（颜色  对象出生时候确认属性）
    def __init__(self,name,age,color):
        # self.name=name
        # self.age=age
        self.color=color
        #super()显示引用父亲对象资产
        super().__init__(name,age)

    def shout(self):#吼叫
        print(f'{self.name} 在汪汪叫')
        super().shout()  #调用父亲代码shout()
    #儿子有优先使用儿子的
    def __str__(self):
        return   f'{self.name},{self.age},{self.color}'

class  AisaDog(Dog): #相对于 Dog  ---》AisaDog子类～
    pass

class  Cat(Animal):
    def  shout(self):
        print(f'{self.name}喵喵叫～')
    def eat(self):
        print(f'吃鱼和老鼠')
class  Bird(Animal):
    def shout(self):
        print(f'{self.name}叽叽喳喳叫～')

def job(a): #实际参数 Dog  Cat  Bird animal  Person  Python多态性 的
    if isinstance(a,Dog):
        print(f'{a.name}看家护院 ')
    elif isinstance(a,Cat):
        print(f'{a.name}抓老鼠 ')
    elif isinstance(a,Bird):
        print(f'{a.name}捉虫子 ')



if __name__ == '__main__':
    d1=  Dog('哈士奇',5,'黑白色')#使用父类构造函数
    A1 = AisaDog('亚洲犬', 2,'彩色')
    c1 = Cat('波斯猫', 3)
    b1 = Bird('鹦鹉', 2)
    print(isinstance(d1,Animal))
    print(isinstance(d1, Dog))
    print(isinstance(d1, Cat))

    job(d1) #根据传递不同类型的对象做不同的职责～
