# 1    Person类(警察对象  匪徒对象 代表了玩家)
#          属性    姓名 name  血量(blood)
#          方法     1  给弹夹装子弹  2枪安装弹夹   3  拿枪  4 开枪
import time


class Person:
    def __init__(self,name): # 在__init__属性  对象出生 就有属性   其他方法属性self  代表后天属性
        self.name=name # 玩家设置名字
        self.blood=100  # 玩家默认值

    #安装子弹
    def  installBullet(self,clip,bullet):
        # 调用弹夹保存子弹
        clip.saveBullets(bullet)
    #安装弹夹
    def installClip(self,gun,clip):
        #调用枪保存连接弹夹
        gun.mountingClip(clip)
#  2    弹夹类 Clip
#        属性   容量 capacity   子弹列表
class Clip:
    def __init__(self,capacity):#容量
        self.capacity=capacity
        #子弹列表
        self.currentList=[]  # 子弹列表空  [bullet对象1,bullet对象2]
#        方法  2.1 安装子弹
    def saveBullets(self,bullet):
        # 代表子弹容量没有满～
        if len(self.currentList)<self.capacity:
            print('正在装弹1颗。。。。')
            time.sleep(0.5)
            self.currentList.append(bullet)#存放子弹
        else:
            print('子弹已满无法追加')

    def __str__(self):
        return  f'弹夹中子弹数量:{len(self.currentList)}/{self.capacity}'

#
#        2.2 弹出子弹
# 3   子弹类  Bullet
class Bullet:
    #      属性    damge 杀伤力      10子弹  20 判断 100 导弹
    def __init__(self,damage):
        self.damge=damage

#     方法   3.1伤害敌人  (敌人血量-子弹杀伤力)
# 4  枪类  Gun
#       属性    弹夹(默认None 没有安装弹夹)
#       方法  4.1  安装连接弹夹  4.2 射击
class Gun:
    def __init__(self):
        self.clip=None
    def __str__(self):
        if self.clip:  #True
            return '枪有弹夹'
        else:
            return '枪没有弹夹'
    def mountingClip(self,clip):
        if  not self.clip: #  None  -->Fasle  非None --》True
            #当前没有弹夹
            #安装弹夹
            print('正在给枪安装弹夹。。')
            time.sleep(2)
            self.clip=clip
if __name__ == '__main__':
    #玩游戏
    police=Person('警察')#玩家对象
    clip=Clip(10) #弹夹容量10
    gun=Gun() #枪对象
    i=1
    print(clip)
    while i<=12:
        b1=Bullet(10)# 子弹杀伤力
       #安装子弹之前
        police.installBullet(clip,b1)
       #安装子弹之后
        i+=1
    print(clip)

    print(gun)  #自测安装弹夹之前
    police.installClip(gun,clip) #玩家安装弹夹
    print(gun) #自测安装弹夹之后