class  bank:
    def __init__(self,brand,money):
        self.brand=brand
        self.__money=money #对象属性用在任何对象方法中
    def getMoney(self):
        user=input('您好，输入您的身份')
        if user in ('张三','001','行长'):
            print('验证通过')
            print('当前账户额度',self.__money)
        else:
            print('没有读取权限')

    def setMoney(self):
        user = input('您好，输入银行工作人员：')
        if user in ('行长','001'):
            money=int(input('您好，输入增加余额：'))
            self.__money+=money
            print('储蓄完毕')
        else:
            print('没有修改权限～')

if __name__ == '__main__':
    b1=bank('工商银行',20000)
    #测试思路
    b1.getMoney()
    #修改余额
    b1.setMoney()
    #再次查看是否修改成功～
    b1.getMoney()